//
//  PersonalizedQuizTests.swift
//  PersonalizedQuizTests
//
//  Created by Kshrugal Reddy Jangalapalli on 10/3/24.
//

import Testing
@testable import PersonalizedQuiz

struct PersonalizedQuizTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
